package com.example.burgerapp

class MenuItem(
    var name: String,
    var cal: String,
    var image: Int,
    var url: String,
    var checked: Boolean
)
