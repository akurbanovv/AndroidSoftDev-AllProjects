package com.example.burgerapp

import java.io.Serializable

class Profile(
    var gender: String,
    var weight: Int,
    var age: Int,
    var feet: Int,
    var inches: Int
) : Serializable

    fun UpdateAge(test: String){}





